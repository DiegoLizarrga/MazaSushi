<?php

//Importamos las cabeceras necesarias 
header("Access-Control-Allow-Origin: *");
header("Content-type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-type, Access-Control-Allow-Headers, Authorization, X-Request-With");

//Importamos los archivos de base de datos y clase de instancia
include_once "../Configuration/database.php";
include_once "../Models/ItemsModel.php";



//Instanciamos la clase de base de datos y accedemos al método de conexión
$objDatabase = new Database();
$db = $objDatabase->getConnection();

  
			//Instanciamos la clase de Shriner
	$objItems = new ItemsModel($db);
//Obtenemos la data del consumo de la API
$data = json_decode(file_get_contents("php://input"));


//Le asignamos la data obtenida del consumo de la API a variables locales
        $objItems->idCliente=$data->idCliente;
echo $objItems->idCliente;

//Ejecutamos el método de consulta y obtenemos el número de filas obtenidas
$stmt = $objItems->getItems();
$rowCount = $stmt->rowCount();


    //Si el número de filas es mayor a 0. Se inicializa un array, se importa la fila actual a la tabla de símbolos, se asocia la data importada con nombres de atributo dentro de un array y se agrega al array principal. Finalmente se convierte a JSON y se arroja un código de estado 200.
if ($rowCount > 0) {

$arrItems = array();

while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {

    extract($row);

    $e = array(
            "idItem" => $idItem,
            "nombre" => $nombre,
            "descripcion" => $descripcion,
            "precio" => $precio,
            "img" => $img,
            
            
    ); 

    array_push($arrItems, $e);
    
}

echo json_encode($arrItems);
http_response_code(200);

//De lo contrario, se arrojará un mensaje de error y un código de estado 404.		

} else {

echo json_encode(
    array("message"=>"No se encontraron items del cliente.")
);
http_response_code(404);

        
}
?>