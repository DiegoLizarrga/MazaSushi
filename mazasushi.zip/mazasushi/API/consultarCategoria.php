<?php

//Importamos las cabeceras necesarias 
	header("Access-Control-Allow-Origin: *");
	header("Content-type: application/json; charset=UTF-8");

	//Importamos los archivos de base de datos y clase de instancia
	include_once "../Configuration/database.php";
	include_once "../Models/MenuModel.php";



	//Instanciamos la clase de base de datos y accedemos al método de conexión
	$objDatabase = new Database();
	$db = $objDatabase->getConnection();

			//Instanciamos la clase de Shriner
	$objMenu = new MenuModel($db);


    $data = json_decode(file_get_contents("php://input"));


	//Ejecutamos el método de consulta y obtenemos el número de filas obtenidas
	$stmt = $objMenu->getCategoria($data->categoria);
	$rowCount = $stmt->rowCount();
	

			//Si el número de filas es mayor a 0. Se inicializa un array, se importa la fila actual a la tabla de símbolos, se asocia la data importada con nombres de atributo dentro de un array y se agrega al array principal. Finalmente se convierte a JSON y se arroja un código de estado 200.
	if ($rowCount > 0) {

		$arrCat = array();

		while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {

			extract($row);

			$e = array(
					"idMenu" => $idMenu,
					"nombre" => $nombre,
					"descripcion" => $descripcion,
					"precio" => $precio,
					"img" => $img,
					
					
			); 

			array_push($arrCat, $e);
			
		}

		echo json_encode($arrCat);
		http_response_code(200);

		//De lo contrario, se arrojará un mensaje de error y un código de estado 404.		
		
	} else {

		echo json_encode(
			array("message"=>"No se encontraron productos registrados.")
		);
		http_response_code(404);
		
	}

?>