<?php

//Importamos las cabeceras necesarias 
	header("Access-Control-Allow-Origin: *");
	header("Content-type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-type, Access-Control-Allow-Headers, Authorization, X-Request-With");

//Importamos los archivos de base de datos y clase de instancia
	include_once "../Configuration/database.php";
	include_once "../Models/ClientesModel.php";

//Instanciamos la clase de base de datos y accedemos al método de conexión
	$objDatabase = new Database();
	$db = $objDatabase->getConnection();

	//Instanciamos la clase de Shriners
	$objCliente = new ClientesModel($db);

//Obtenemos la data del consumo de la API
	$data = json_decode(file_get_contents("php://input"));

	//Asignamos la data recuperada del consumo de la API a los atributos del objeto
	$objCliente->idCliente=$data->idCliente;
    $objCliente->calle = $data->calle;
	$objCliente->colonia = $data->colonia;

    if (isset($data->numeroInt)){
	$objCliente->numeroInt = $data->numeroInt;}

	$objCliente->numeroExt = $data->numeroExt;
	$objCliente->telefono = $data->telefono;

	

	//Ejecutamos el método con la query de creación. Si es exitosa devolverá un código de estado 200 y un mensaje de éxito, de lo contrario devolverá un mensaje de error y un código 404


	if ($objCliente->modDireccion()) {

		echo "Su direccion ha sido modificada";
		echo "Código de estado de la respuesta del servidor a la petición: ".http_response_code(200).".";
	} else {

		echo json_encode("Error al modificar su direccion.<br>");
		echo "Código de estado de la respuesta del servidor a la petición: ".http_response_code(404).".";
		
	}

?>