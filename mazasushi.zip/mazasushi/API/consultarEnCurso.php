<?php

//Importamos las cabeceras necesarias 
header("Access-Control-Allow-Origin: *");
	header("Content-type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-type, Access-Control-Allow-Headers, Authorization, X-Request-With");

	//Importamos los archivos de base de datos y clase de instancia
	include_once("../Configuration/database.php");
	include_once("../Models/PedidosModel.php");

	//Instanciamos la clase de base de datos y accedemos al método de conexión
	$objDatabase = new Database();
	$db = $objDatabase->getConnection();

		//Instanciamos la clase de Shriner
	$objPedido = new PedidosModel($db);

//Obtenemos la data del consumo de la API
		$data = json_decode(file_get_contents("php://input"));


//Le asignamos la data obtenida del consumo de la API a variables locales
		$objPedido->idSucursal=$data->idSucursal;

		//Ejecutamos el método con la query de búsqueda con las variables como parámetros. Si es exitosa devolverá un código de estado 200 y un mensaje de éxito, de lo contrario devolverá un mensaje de error y un código 404

	$r=$objPedido->getEnCurso();
    $rowCount = $r->rowCount();

    if ($rowCount > 0) {

		$arrPedido = array();

		while ($row = $r->fetch(PDO::FETCH_ASSOC)) {

			extract($row);

			$e = array(
                "idPedido" => $idPedido,
					"idCliente" => $idCliente,
					"descripcion" => $descripcion,
					"total" => $total,
					"pago" => $pago
					
			); 

			array_push($arrPedido, $e);
			
		}

		echo json_encode($arrPedido);
		http_response_code(200);

		//De lo contrario, se arrojará un mensaje de error y un código de estado 404.		
		
	}
	else {
		echo json_encode(
			array("message"=>"No se encontraron pedidos")
		);
				http_response_code(404);

	}

?>