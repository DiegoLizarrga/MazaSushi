<?php

//Importamos las cabeceras necesarias 
	header("Access-Control-Allow-Origin: *");
	header("Content-type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-type, Access-Control-Allow-Headers, Authorization, X-Request-With");

	//Importamos los archivos de base de datos y clase de instancia
	include_once("../Configuration/database.php");
	include_once("../Models/ItemsModel.php");

	//Instanciamos la clase de base de datos y accedemos al método de conexión
	$objDatabase = new Database();
	$db = $objDatabase->getConnection();

	//Instanciamos la clase de Paciente
	$objItem = new ItemsModel($db);

//Obtenemos la data del consumo de la API
	$data = json_decode(file_get_contents("php://input"));

	//Obtenemos el ID del paciente por GET. Si no existe se termina el script
	$objItem->idItem = $data->idItem;

	
	//Ejecutamos el método con la query de eliminación. Si es exitosa devolverá un código de estado 200 y un mensaje de éxito, de lo contrario devolverá un mensaje de error y un código 404

	if ($objItem->deleteItem()) {

		echo "El item ha sido eliminado.<br>";
		echo "Código de estado de la respuesta del servidor a la petición: ".http_response_code(200).".";
	
	} else {

		echo json_encode("Error al eliminar al item.");
		echo "Código de estado de la respuesta del servidor a la petición: ".http_response_code(404).".";

	}

?>