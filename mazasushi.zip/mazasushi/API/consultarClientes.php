<?php

//Importamos las cabeceras necesarias 
	header("Access-Control-Allow-Origin: *");
	header("Content-type: application/json; charset=UTF-8");

	//Importamos los archivos de base de datos y clase de instancia
	include_once "../Configuration/database.php";
	include_once "../Models/ClientesModel.php";



	//Instanciamos la clase de base de datos y accedemos al método de conexión
	$objDatabase = new Database();
	$db = $objDatabase->getConnection();

			//Instanciamos la clase de Shriner
	$objCliente = new ClientesModel($db);

	//Ejecutamos el método de consulta y obtenemos el número de filas obtenidas
	$stmt = $objCliente->getClientes();
	$rowCount = $stmt->rowCount();
	

			//Si el número de filas es mayor a 0. Se inicializa un array, se importa la fila actual a la tabla de símbolos, se asocia la data importada con nombres de atributo dentro de un array y se agrega al array principal. Finalmente se convierte a JSON y se arroja un código de estado 200.
	if ($rowCount > 0) {

		$arrClientes = array();

		while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {

			extract($row);

			$e = array(
					"idCliente" => $idCliente,
					"nombre" => $nombre,
					"usuario" => $usuario,
					"contrasena" => $contrasena,
					"calle" => $calle,
					"colonia" => $colonia,
					"numeroInt" => $numeroInt,
					"numeroExt" => $numeroExt,
					"telefono" => $telefono
					
			); 

			array_push($arrClientes, $e);
			
		}

		echo json_encode($arrClientes);
		http_response_code(200);

		//De lo contrario, se arrojará un mensaje de error y un código de estado 404.		
		
	} else {

		echo json_encode(
			array("message"=>"No se encontraron clientes registrados.")
		);
		http_response_code(404);
		
	}

?>