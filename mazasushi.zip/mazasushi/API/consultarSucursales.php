<?php

//Importamos las cabeceras necesarias 
	header("Access-Control-Allow-Origin: *");
	header("Content-type: application/json; charset=UTF-8");

	//Importamos los archivos de base de datos y clase de instancia
	include_once "../Configuration/database.php";
	include_once "../Models/SucursalModel.php";



	//Instanciamos la clase de base de datos y accedemos al método de conexión
	$objDatabase = new Database();
	$db = $objDatabase->getConnection();

			//Instanciamos la clase de Shriner
	$objSucursales = new SucursalModel($db);

	//Ejecutamos el método de consulta y obtenemos el número de filas obtenidas
	$stmt = $objSucursales->getSucursales();
	$rowCount = $stmt->rowCount();
	

			//Si el número de filas es mayor a 0. Se inicializa un array, se importa la fila actual a la tabla de símbolos, se asocia la data importada con nombres de atributo dentro de un array y se agrega al array principal. Finalmente se convierte a JSON y se arroja un código de estado 200.
	if ($rowCount > 0) {

		$arrSucursales = array();

		while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {

			extract($row);

			$e = array(
					"idSucursal" => $idSucursal,
					"responsable" => $responsable,
					"usuario" => $usuario,
					"contrasena" => $contrasena,
					"calle" => $calle,
					"colonia" => $colonia,
					"numeroExt" => $numeroExt,
					"telefono" => $telefono
					
			); 

			array_push($arrSucursales, $e);
			
		}

		echo json_encode($arrSucursales);
		http_response_code(200);

		//De lo contrario, se arrojará un mensaje de error y un código de estado 404.		
		
	} else {

		echo json_encode(
			array("message"=>"No se encontraron sucursales registrados.")
		);
		http_response_code(404);
		
	}

?>