<?php

	require_once("../Configuration/config.php");
	

 /**
  * Summary of ItemsModel
  */
	class ItemsModel {


		//Conexión
		private $conn;

		//Tabla de la BD a utilizar
		private $table = TABLA_ITEMS;

		//Columnas de la tabla de la base de datos
		public $idItem;

		public $nombre;
		public $descripcion;
		public $precio;
		public $img;
		public $idCliente;

		

		//Establecer conexión con la BD
		public function __construct($db) {

			$this->conn = $db;

		}


        public function setItem() {

		

			$consultaSQL = "INSERT INTO " . $this->table . " (idCliente, nombre, descripcion, precio, img) 
            VALUES (:idCliente, :nombre, :descripcion, :precio, :img) ";

			$stmt = $this->conn->prepare($consultaSQL);

            $stmt->bindParam(":idCliente", $this->idCliente);
			$stmt->bindParam(":nombre", $this->nombre);
				$stmt->bindParam(":descripcion", $this->descripcion);
			$stmt->bindParam(":precio", $this->precio);
					$stmt->bindParam(":img", $this->img);
			
			if ($stmt->execute()) {

				return true;
			
			} else {

				return false;

			}
		
		}

       

		public function getItems() {

			$sql = "SELECT * FROM ".$this->table . " WHERE idCliente = ?";
			$stmt = $this->conn->prepare($sql);
            $stmt->bindParam(1, $this->idCliente);

			$stmt->execute();
			return $stmt;

		}
        
        public function deleteItem() {
			
			$sql = "DELETE FROM ".$this->table." WHERE idItem = ?";
			$stmt = $this->conn->prepare($sql);


			$stmt->bindParam(1, $this->idItem);

			if($stmt->execute()) {
				return true;
			} else {
				return false;
			}

		}


		public function prepPedido($idCliente) {

			$sql = "SELECT * FROM ".$this->table . " WHERE idCliente = '$idCliente'";
			$stmt = $this->conn->prepare($sql);

			$s1 = $stmt->execute();
			$items= $stmt->fetchAll(PDO::FETCH_ASSOC);

            $descPedido = "";
			$total = 0.0;

			foreach ($items as $row) {
				extract($row);
$descPedido .= $nombre;				
$total += (float) $precio;

			
			}

			$r = array("descripcion" => $descPedido, "total" => $total);


			$sql2 = "DELETE FROM " . $this->table . " WHERE idCliente = '$idCliente'";
			$stm2 = $this->conn->prepare($sql2);
			$s2 = $stm2->execute();



if($s1 && $s2) {
				return $r;
			} else {
				return false;
			}




		}

		


	}

?>