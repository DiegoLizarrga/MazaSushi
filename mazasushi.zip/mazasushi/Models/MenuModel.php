<?php

	require_once("../Configuration/config.php");

	class MenuModel {


		//Conexión
		private $conn;

		//Tabla de la BD a utilizar
		private $table = TABLA_MENU;

		//Columnas de la tabla de la base de datos
		public $idMenu;

		public $nombre;
		public $descripcion;
		public $precio;
		public $img;
		public $categoria;

		

		//Establecer conexión con la BD
		public function __construct($db) {

			$this->conn = $db;

		}


        public function getMenu() {

			$sql = "SELECT * FROM ". $this->table;
			$stmt = $this->conn->prepare($sql);
			$stmt->execute();
			return $stmt;

		}


		public function getCategoria($categoria) {

			$sql = "SELECT * FROM ".$this->table . " WHERE categoria = '$categoria'";
			$stmt = $this->conn->prepare($sql);
			$stmt->execute();
			return $stmt;

		}


		


	}

?>