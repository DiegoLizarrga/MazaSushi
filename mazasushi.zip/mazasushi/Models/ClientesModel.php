<?php

	require_once("../Configuration/config.php");

	class ClientesModel {


		//Conexión
		private $conn;

		//Tabla de la BD a utilizar
		private $table = TABLA_CLIENTES;

		//Columnas de la tabla de la base de datos
		public $idCliente;

		public $nombre;
		public $usuario;
		public $contrasena;
		public $calle;
		public $colonia;

		public $numeroInt;
		public $numeroExt;
		public $telefono;
		

		//Establecer conexión con la BD
		public function __construct($db) {

			$this->conn = $db;

		}


		public function getClientes() {

			$sql = "SELECT * FROM ".$this->table."";
			$stmt = $this->conn->prepare($sql);
			$stmt->execute();
			return $stmt;

		}


		

		public function setCliente() {

		

			$consultaSQL = "INSERT INTO " . $this->table . " (nombre, usuario, contrasena, calle, colonia,
            numeroInt, numeroExt, telefono) VALUES (:nombre, :usuario, :contrasena, :calle, :colonia, :numeroInt,
            :numeroExt, :telefono) ";

			$stmt = $this->conn->prepare($consultaSQL);

			$this->nombre=htmlspecialchars($this->nombre);
				$this->usuario=htmlspecialchars($this->usuario);
			$this->contrasena=htmlspecialchars($this->contrasena);
				$this->calle=htmlspecialchars($this->calle);
				$this->colonia=htmlspecialchars($this->colonia);
			$this->numeroInt=htmlspecialchars($this->numeroInt);
			$this->numeroExt=htmlspecialchars($this->numeroExt);
			$this->telefono=htmlspecialchars($this->telefono);	
			
			
			$stmt->bindParam(":nombre", $this->nombre);
				$stmt->bindParam(":usuario", $this->usuario);
			$stmt->bindParam(":contrasena", $this->contrasena);
					$stmt->bindParam(":calle", $this->calle);
				$stmt->bindParam(":colonia", $this->colonia);
			$stmt->bindParam(":numeroInt", $this->numeroInt);
			$stmt->bindParam(":numeroExt", $this->numeroExt);
			$stmt->bindParam(":telefono", $this->telefono);
			
			if ($stmt->execute()) {

				return true;
			
			} else {

				return false;

			}
		
		}


		public function modContrasena($contrasena) {

			$consultaSQL = "UPDATE " . $this->table . " SET contrasena= '$contrasena' WHERE idCliente=:idCliente ";

			$stmt = $this->conn->prepare($consultaSQL);

		
				$stmt->bindParam(":idCliente", $this->idCliente);
		
			if ($stmt->execute()) {

				return true;

			} else {

				return false;
			
			}

		}


        public function modDireccion() {

		

			$consultaSQL = " UPDATE " . $this->table . " SET calle= :calle, colonia = :colonia,  
            numeroInt = :numeroInt, numeroExt= :numeroExt, telefono= :telefono WHERE idCliente =:idCliente ";

			$stmt = $this->conn->prepare($consultaSQL);

			$this->calle=htmlspecialchars($this->calle);
				$this->colonia=htmlspecialchars($this->colonia);
			

				$stmt->bindParam(":idCliente", $this->idCliente);
			$stmt->bindParam(":calle", $this->calle);
				$stmt->bindParam(":colonia", $this->colonia);
			$stmt->bindParam(":numeroInt", $this->numeroInt);
					$stmt->bindParam(":numeroExt", $this->numeroExt);
			$stmt->bindParam(":telefono", $this->telefono);
		

			if ($stmt->execute()) {

				return true;

			} else {

				return false;

			}

		}

        public function loginCliente($usuario, $contrasena){
            $consultaLogin = "SELECT * FROM ". $this->table . " WHERE usuario = '$usuario' AND contrasena = '$contrasena'";
            $stmtLogin = $this->conn->prepare($consultaLogin);
			$stmtLogin->execute();

			$dataRow = $stmtLogin->fetch(PDO::FETCH_ASSOC);

			if ($dataRow!=null){

				$this->idCliente = $dataRow['idCliente'];
			

return true;
			}

			else {
				return false;
			}
        }



	}

?>