<?php

	require_once("../Configuration/config.php");
	require_once("ItemsModel.php");




 /**
  * Summary of ItemsModel
  */
	class PedidosModel extends ItemsModel{


		//Conexión
		private $conn;

		//Tabla de la BD a utilizar
		private $table = TABLA_PEDIDOS;


		//Columnas de la tabla de la base de datos
		public $idPedido;

		public $idCliente;
		public $idSucursal;
		public $descripcion;
		public $total;
		public $estado;
        public $pago;


		

		//Establecer conexión con la BD
		public function __construct($db) {

			$this->conn = $db;

		}


        public function setPedido() {

           $objItem = new ItemsModel($this->conn);
           $r = $objItem->prepPedido($this->idCliente);


            $descripcion = $r['descripcion'];
            $total = $r['total'];

		



			$consultaSQL = "INSERT INTO " . $this->table . " (idCliente, idSucursal, descripcion,
            total, estado, pago) VALUES (:idCliente, :idSucursal, '$descripcion', '$total', '1', :pago) ";

			$stmt = $this->conn->prepare($consultaSQL);

            $stmt->bindParam(":idCliente", $this->idCliente);
			$stmt->bindParam(":idSucursal", $this->idSucursal);
			$stmt->bindParam(":pago", $this->pago);

			
			if ($stmt->execute()) {

				return true;
			
			} else {

				return false;

			}
		
		}

       

		public function finalizarPedido() {

			$consultaSQL = "UPDATE " . $this->table . " SET estado= '2' WHERE idPedido=:idPedido ";

			$stmt = $this->conn->prepare($consultaSQL);

		
				$stmt->bindParam(":idPedido", $this->idPedido);
		
			if ($stmt->execute()) {

				return true;

			} else {

				return false;
			
			}

		}

		public function getEnCurso(){
            $consultaSQL = "SELECT * FROM ". $this->table . " WHERE idSucursal = :idSucursal 
			AND estado  = '1'";
			$stmt = $this->conn->prepare($consultaSQL);

			$stmt->bindParam(":idSucursal", $this->idSucursal);

			$stmt->execute();

		return $stmt;
        }
		
		public function getFinalizados(){
            $consultaSQL = "SELECT * FROM ". $this->table . " WHERE idSucursal = :idSucursal 
			AND estado  = '2'";
			$stmt = $this->conn->prepare($consultaSQL);

			$stmt->bindParam(":idSucursal", $this->idSucursal);

			$stmt->execute();

		return $stmt;
        }

	}

?>