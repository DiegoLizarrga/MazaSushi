<?php

	require_once("../Configuration/config.php");

	class SucursalModel {


		//Conexión
		private $conn;

		//Tabla de la BD a utilizar
		private $table = TABLA_SUCURSALES;

		//Columnas de la tabla de la base de datos
		public $idSucursal;

		public $responsable;
		public $usuario;
		public $contrasena;
		public $calle;
		public $colonia;

		public $numeroExt;
		public $telefono;
		

		//Establecer conexión con la BD
		public function __construct($db) {

			$this->conn = $db;

		}


		public function getSucursales() {

			$sql = "SELECT * FROM ".$this->table."";
			$stmt = $this->conn->prepare($sql);
			$stmt->execute();
			return $stmt;

		}


		

		

        public function loginSucursal($usuario, $contrasena){
            $consultaLogin = "SELECT * FROM ". $this->table . " WHERE usuario = '$usuario' AND contrasena = '$contrasena'";
            $stmtLogin = $this->conn->prepare($consultaLogin);
			$stmtLogin->execute();

			$dataRow = $stmtLogin->fetch(PDO::FETCH_ASSOC);

			if ($dataRow!=null){

				$this->idSucursal = $dataRow['idSucursal'];
			

return true;
			}

			else {
				return false;
			}
        }



	}

?>