<?php

	
	const BASE_URL = "http://148.227.227.4/~usuario04/mazasushi";

	const API = BASE_URL."/API";
	const MODEL = BASE_URL."/Models";
	const CONTROLLER = BASE_URL."/Controllers";
	const VIEW = BASE_URL."/Views";
	//Zona horaria
	date_default_timezone_set('America/Mazatlan');

	const DB_HOST = "localhost";
	const DB_NAME = "usuario04";
	const DB_USER = "usuario04";
	const DB_PASSWORD = "usuario";
	const DB_CHARSET = "utf8";

	
/*
	const DB_HOST = "localhost";
	const DB_NAME = "sci";
	const DB_USER = "root";
	const DB_PASSWORD = "";
	const DB_CHARSET = "utf8";
*/
	//Nombre de tablas
	const TABLA_MENU = "menu";
	const TABLA_CLIENTES = "cliente";
	const TABLA_SUCURSALES = "sucursal";
	const TABLA_ITEMS = "item";
	const TABLA_PEDIDOS = "pedidos";
	
?>